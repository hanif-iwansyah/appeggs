package com.hindustries;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppEggsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppEggsApplication.class, args);
	}

}
